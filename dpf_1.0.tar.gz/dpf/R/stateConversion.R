convert4to8 <- function(path){
    cpps = 0:7
    tm1 = c(1,1,1,2,2,3,3,4)
    t1 = c(1,2,4,2,3,1,3,1)
    n = length(path)
    npath = c(1,path[-n])
    path4 = integer(n)
    for(i in 1:n){
        path4[i] = cpps[tm1==npath[i] & t1==path[i]]
    }
    return(path4)
}

convert8to4 <- function(path){
    t1 = c(1,2,4,2,3,1,3,1)
    path8 = t1[path+1]
    return(path8)
}
